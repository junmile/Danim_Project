package com.kh.danim.help.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.kh.danim.help.model.service.HelpService;
import com.kh.danim.help.model.vo.Help;
import com.kh.danim.user.controller.UserController;
import com.kh.danim.user.model.vo.User;

@Controller
public class HelpController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private HelpService helpService;

	@RequestMapping("insertview.do")
	public String insertView() {
		return "insertview";
	}
	
	@RequestMapping(value = "insertdanim.do", method = RequestMethod.POST)
	public String insertHelp(Help help, HttpServletRequest request, MultipartHttpServletRequest mtp) {
		List<MultipartFile> list = mtp.getFiles("images[]");
		String path = request.getSession().getServletContext().getRealPath("/resources/upfiles");
		logger.info("full : " + path);
		String fileRename = "";
		String ofile = "";
		String rfile = "";
				
		for (MultipartFile multipartFile : list) {
			/*logger.info("originalFileName : " + multipartFile.getOriginalFilename());
			logger.info("fileSize : " + multipartFile.getSize());*/
			fileRename = help.getHelpno()+"_"+ System.currentTimeMillis()+"_"+multipartFile.getOriginalFilename();
			ofile += multipartFile.getOriginalFilename() + ",";
			rfile += fileRename + ",";
			try {
				multipartFile.transferTo(new File(path +"\\" + fileRename));
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		}
		help.setImage(ofile);
		help.setRenameimage(rfile);
		logger.info(help.toString());
		
		int result = helpService.insertHelp(help);
		String str="";
		if(result>0) {
			str = "redirect:danimChange.do";
		}
		
		return str;
	}
	
	
	@RequestMapping("helpList.do")
	public ModelAndView danimChangeMethod(ModelAndView mv, Help help) {
//		logger.info("다님이 페이지 접속..");
		
		return mv;
	}
}
