package com.kh.danim.help.model.vo;

import java.util.Date;

public class Help {
	
	private int helpno;
	private String helpid;
	private String helperid;
	private String roadaddress;
	private String detailaddress;
	private String locationcode;
	private String targetroadaddress;
	private String targetdetailaddress;
	private String time;
	private String endtime;
	private String reserdate;
	private String resertime;
	private String usingtime;
	private String contents;
	private String matching;
	private String pay;
	private String paym;
	private String status;
	private String category;
	private String helperlist;
	private String image;
	private String renameimage;
	
	public Help() {}

	public Help(int helpno, String helpid, String helperid, String roadaddress, String detailaddress,
			String locationcode, String targetroadaddress, String targetdetailaddress, String time, String endtime,
			String reserdate, String resertime, String usingtime, String contents, String matching, String pay,
			String paym, String status, String category, String helperlist, String image, String renameimage) {
		super();
		this.helpno = helpno;
		this.helpid = helpid;
		this.helperid = helperid;
		this.roadaddress = roadaddress;
		this.detailaddress = detailaddress;
		this.locationcode = locationcode;
		this.targetroadaddress = targetroadaddress;
		this.targetdetailaddress = targetdetailaddress;
		this.time = time;
		this.endtime = endtime;
		this.reserdate = reserdate;
		this.resertime = resertime;
		this.usingtime = usingtime;
		this.contents = contents;
		this.matching = matching;
		this.pay = pay;
		this.paym = paym;
		this.status = status;
		this.category = category;
		this.helperlist = helperlist;
		this.image = image;
		this.renameimage = renameimage;
	}

	public int getHelpno() {
		return helpno;
	}

	public void setHelpno(int helpno) {
		this.helpno = helpno;
	}

	public String getHelpid() {
		return helpid;
	}

	public void setHelpid(String helpid) {
		this.helpid = helpid;
	}

	public String getHelperid() {
		return helperid;
	}

	public void setHelperid(String helperid) {
		this.helperid = helperid;
	}

	public String getRoadaddress() {
		return roadaddress;
	}

	public void setRoadaddress(String roadaddress) {
		this.roadaddress = roadaddress;
	}

	public String getDetailaddress() {
		return detailaddress;
	}

	public void setDetailaddress(String detailaddress) {
		this.detailaddress = detailaddress;
	}

	public String getLocationcode() {
		return locationcode;
	}

	public void setLocationcode(String locationcode) {
		this.locationcode = locationcode;
	}

	public String getTargetroadaddress() {
		return targetroadaddress;
	}

	public void setTargetroadaddress(String targetroadaddress) {
		this.targetroadaddress = targetroadaddress;
	}

	public String getTargetdetailaddress() {
		return targetdetailaddress;
	}

	public void setTargetdetailaddress(String targetdetailaddress) {
		this.targetdetailaddress = targetdetailaddress;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public String getReserdate() {
		return reserdate;
	}

	public void setReserdate(String reserdate) {
		this.reserdate = reserdate;
	}

	public String getResertime() {
		return resertime;
	}

	public void setResertime(String resertime) {
		this.resertime = resertime;
	}

	public String getUsingtime() {
		return usingtime;
	}

	public void setUsingtime(String usingtime) {
		this.usingtime = usingtime;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getMatching() {
		return matching;
	}

	public void setMatching(String matching) {
		this.matching = matching;
	}

	public String getPay() {
		return pay;
	}

	public void setPay(String pay) {
		this.pay = pay;
	}

	public String getPaym() {
		return paym;
	}

	public void setPaym(String paym) {
		this.paym = paym;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getHelperlist() {
		return helperlist;
	}

	public void setHelperlist(String helperlist) {
		this.helperlist = helperlist;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getRenameimage() {
		return renameimage;
	}

	public void setRenameimage(String renameimage) {
		this.renameimage = renameimage;
	}

/*	@Override
	public String toString() {
		return "Help [helpno=" + helpno + ", helpid=" + helpid + ", helperid=" + helperid + ", roadaddress="
				+ roadaddress + ", detailaddress=" + detailaddress + ", locationcode=" + locationcode
				+ ", targetroadaddress=" + targetroadaddress + ", targetdetailaddress=" + targetdetailaddress
				+ ", time=" + time + ", endtime=" + endtime + ", reserdate=" + reserdate + ", resertime=" + resertime
				+ ", usingtime=" + usingtime + ", contents=" + contents + ", matching=" + matching + ", pay=" + pay
				+ ", paym=" + paym + ", status=" + status + ", category=" + category + ", helperlist=" + helperlist
				+ ", image=" + image + ", renameimage=" + renameimage + "]";
	}
	*/
	@Override
	public String toString() {
		return "\nHelp [\nhelpno=" + helpno +"\nhelpid=" + helpid + "\nhelperid=" + helperid + "\nroadaddress="
				+ roadaddress + "\ndetailaddress=" + detailaddress + "\nlocationcode=" + locationcode
				+ "\ntargetroadaddress=" + targetroadaddress + "\ntargetdetailaddress=" + targetdetailaddress
				+ "\ntime=" + time + "\nendtime=" + endtime + "\nreserdate=" + reserdate + "\nresertime=" + resertime
				+ "\nusingtime=" + usingtime + "\ncontents=" + contents + "\nmatching=" + matching + "\npay=" + pay
				+ "\npaym=" + paym + "\nstatus=" + status + "\ncategory=" + category + "\nhelperlist=" + helperlist
				+ "\nimage=" + image + "\nrenameimage=" + renameimage + "]";
	}
	
	


	
	
	
}
