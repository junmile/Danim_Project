package com.kh.danim.help.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.danim.help.model.dao.HelpDao;
import com.kh.danim.help.model.vo.Help;

@Service("danimService")
public class HelpServiceImpl implements HelpService{
	
	@Autowired
	private HelpDao helpDao;

	@Override
	public int insertHelp(Help help) {
		return helpDao.insertHelp(help);
	}
}
