package com.kh.danim.help.model.service;

import com.kh.danim.help.model.vo.Help;

public interface HelpService {

	int insertHelp(Help help);

}
