package com.kh.danim.help.model.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kh.danim.help.model.vo.Help;

@Repository
public class HelpDao {

	@Autowired
	private SqlSessionTemplate sqlSession;
	

	public int insertHelp(Help help) {
		return sqlSession.insert("helpMapper.insertHelp", help);
	}
}
